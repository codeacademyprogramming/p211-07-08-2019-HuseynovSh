﻿using System;

namespace P211_Delegate_Event
{
    class Program
    {
        #region Delegate as callbackFunc
        //public delegate bool FilterFunctions(int number); //delegate - nümayəndə, təmsilçi

        //Action<int, string> //represents methods which return void and accept parameters: int, string
        //Action<Math, string, bool> //represents methods which return void and accept parameters: Math, string, bool

        //Func<string> //represents methods which return string and accept no parameters.
        //Func<int, string, int[]> //represents methods which return int[] and accept parameters: int, string

        //static void Main(string[] args)
        //{
        //    var numbers = new int[] { 10, 5, 3, 7, 2 };

        //    //using delegate with separate method
        //    Console.WriteLine(SumFilter(numbers, IsOdd));

        //    //using delegate with anonymous method
        //    Console.WriteLine(SumFilter(numbers, delegate (int n) {
        //        return n % 2 == 0;
        //    }));

        //    //using delegate with lambda expressions
        //    Console.WriteLine(SumFilter(numbers, n => n % 2 == 0));

        //    //using delegate with instance method (Thanks to Rashadddddd, not Sebuhi)
        //    Math m = new Math();
        //    Console.WriteLine(SumFilter(numbers, m.IsGreaterThan100));
        //}

        //static int SumFilter(int[] numbers, FilterFunctions callbackFn)
        //static int SumFilter(int[] numbers, Func<int, bool> callbackFn)
        //{
        //    int total = 0;
        //    foreach (var n in numbers)
        //    {
        //        if (callbackFn(n))
        //        {
        //            total += n;
        //        }
        //    }

        //    return total;
        //}

        //static bool IsEven(int num) => num % 2 == 0;
        //static bool IsOdd(int num) => num % 2 != 0;
        //static bool IsOlderThan10(int num) => num > 10;
        #endregion

        static void Main()
        {
            #region Multicasting delegate
            //Action<string>[] actions = 
            //    new Action<string>[] { GreetInAzerbaijani, GreetInEnglish, GreetInRussian, GreetInFrench };

            //Action<string> demoGreeters = null;

            //foreach (var m in actions)
            //{
            //    demoGreeters += m;
            //}

            //demoGreeters("Sebuhi");

            //Action<string> greeters = GreetInAzerbaijani;
            //greeters += GreetInEnglish;
            //greeters += GreetInGerman;
            //greeters += GreetInFrench;
            //greeters += GreetInArabic;
            //greeters += GreetInRussian;

            //greeters("Samir");

            //Console.WriteLine("-------------------------");

            //greeters -= GreetInArabic;
            //greeters -= GreetInRussian;
            //greeters("Samir");

            //greeters = null;
            //greeters("Samir");

            //static void GreetInAzerbaijani(string name)
            //{
            //    Console.WriteLine($"{name}, Salam, Xoş gəlmisiniz.");
            //}

            //static void GreetInRussian(string n)
            //{
            //    Console.WriteLine($"{n}, Привет, добро пожаловать.");
            //}

            //static void GreetInEnglish(string name)
            //{
            //    Console.WriteLine($"{name}, Hello, Welcome");
            //}

            //static void GreetInGerman(string name)
            //{
            //    Console.WriteLine($"{name}, Guten Tag. Willkommen");
            //}

            //static void GreetInFrench(string name)
            //{
            //    Console.WriteLine($"{name}, Salut, bienvenue.");
            //}

            //static void GreetInArabic(string name)
            //{
            //    Console.WriteLine($"{name}, اهلا اهلا");
            //}

            #endregion

            OilStock azeriLigthStock = new OilStock(100);

            azeriLigthStock.OnPriceChanged += AzeriLightPriceChangedEventListener2;
            azeriLigthStock.OnPriceChanged += AzeriLightPriceChangedEventListener;

            azeriLigthStock.Price = 100;
            azeriLigthStock.Price = 100;
            azeriLigthStock.Price = 90;
        }

        static void AzeriLightPriceChangedEventListener()
        {
           Console.WriteLine("Azeri Lightin qiymeti deyisdi.");
        }

        static void AzeriLightPriceChangedEventListener2()
        {
            Console.WriteLine("Azeri Lightin qiymeti deyisdi 2.");
        }
    }

    //class Math
    //{
    //    public bool IsGreaterThan100(int number) => number > 100;
    //}

    class OilStock
    {
        private decimal _oldPrice;
        private decimal _newPrice;

        public event Action OnPriceChanged; 

        public OilStock(decimal price)
        {
            _oldPrice = _newPrice = price;
        }

        public decimal Price
        {
            get {
                return _newPrice;
            }
            set
            {
                _oldPrice = _newPrice;
                _newPrice = value;

                if(_newPrice != _oldPrice)
                {
                    OnPriceChanged();
                }
            }
        }
    }
}
